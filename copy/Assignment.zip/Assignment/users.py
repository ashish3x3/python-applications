# import sqlite3 as lite
# import sys

# USERFILL= [
	
# 		{'ash','ash'},
# 		{'san','san'},
		
# ]

# conn=lite.connect(users.db)

# with conn:

# 	curr=conn.cursor()

# 	curr.execute('DROP TABLE IF EXISTS USER')
# 	cur.execute('CREATE TABLE USER (username TEXT,password TEXT)')
# 	curr.executemany("INSERT INTO USER VALUES (?,?)",USERFILL)