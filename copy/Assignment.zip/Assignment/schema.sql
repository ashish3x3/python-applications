drop table if exists user;
    create table user (
       
        username text primary key not null,
        password text null
    );

    


INSERT INTO 'user' values ('ash','ash');
INSERT INTO 'user' values ('man','ash');
INSERT INTO 'user' values ('san','ash');
